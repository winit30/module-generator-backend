# Modules

A module system gives you basic backend codes

Open a terminal and run 
  
    mongod
    
Go into your project directory and run 
  
    npm install
    
In the same directory after installing dependacies, run 
    
    npm start
    
     
    
  

